fun main()
{
val r=Robot("clowny")
    r.alarm(day="tuesday",time="5pm")
    r.coffee(type="black",sugar=10)
    r.water(temp=10)
    r.bag(day="tuesday")
    r.food()
    r.iron(cloth="jumpsuit")
}